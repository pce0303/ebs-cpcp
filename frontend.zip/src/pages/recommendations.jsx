import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './recommendations.css';
import EBS from '../ebsi.png';
import MEGA from '../megastudy.jpg';

const Recommendations = () => {
  const location = useLocation();
  const navigate = useNavigate();
  // Home에서 전달받은 selectedDateFull도 함께 받습니다.
  const { subject, category, difficulty, selectedDateFull } = location.state || {};

  const [availableCourses, setAvailableCourses] = useState([]);
  const [selectedCourses, setSelectedCourses] = useState([]);

  // 가상 강좌 목록 (이전과 동일)
  const allCourses = [
    { id: 1, title: '[2023 수능특강] 윤혜정의 독서', logo: EBS, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 2, title: '[2023 54수능특강] 이름이 긴 강좌는 스크롤로 확인 가능 ~~ 강민철의 독서', logo: MEGA, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 3, title: '[2023 수능특강] 윤혜정의 독서', logo: EBS, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 4, title: '[2023 수능특강] 강민철의 독서', logo: MEGA, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 5, title: '[2023 수능특강] 윤혜정의 독서', logo: EBS, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 6, title: '[2023 수능특강] dsadfadfadfadfadfadfafdfadfadfadfadfadadad강민철의 독서', logo: MEGA, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 7, title: '[2023 수능특강] 윤혜정의 독서', logo: EBS, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 8, title: '[2023 수능특강] dsadfadfadfadfadfadfafdfadfadfadfadfadadad강민철의 독서', logo: MEGA, subject: '국어', category: '독서', difficulty: '개념' },
    { id: 9, title: '[2023 수능특강] 윤혜정의 독서', logo: EBS, subject: '국어', category: '독서', difficulty: '심화' },
    { id: 10, title: '[2023 수능특강] 윤혜정의 문학', logo: EBS, subject: '국어', category: '문학', difficulty: '개념' },
    { id: 11, title: '[2023 수능특강] 윤혜정의문학', logo: EBS, subject: '국어', category: '문학', difficulty: '심화' },
    { id: 12, title: '[2023 수능특강] 정승제의 수1',  logo: EBS, subject: '수학', category: '수1', difficulty: '개념' },
    { id: 13, title: '[2023 수능특강] 정승제의 미적분', logo: EBS, subject: '수학', category: '미적분', difficulty: '개념' },
    { id: 14, title: '[2023 수능특강] 조정식의 문법', logo: MEGA, subject: '영어', category: '문법', difficulty: '심화' },
  ];

  useEffect(() => {
    // subject, category, difficulty 또는 selectedDateFull이 변경될 때 필터링
    const filteredCourses = allCourses.filter(course =>
      course.subject === subject &&
      course.category === category &&
      course.difficulty === difficulty
    );
    setAvailableCourses(filteredCourses);
    setSelectedCourses([]);
  }, [subject, category, difficulty, selectedDateFull]); // selectedDateFull도 의존성 배열에 추가

  const handleCheckboxChange = (course) => {
    setSelectedCourses(prevSelectedCourses => {
      const isSelected = prevSelectedCourses.find(c => c.id === course.id);

      if (isSelected) {
        return prevSelectedCourses.filter(c => c.id !== course.id);
      } else {
        return [...prevSelectedCourses, course];
      }
    });
  };

  // "선택" 버튼 클릭 시 -> Plan 페이지로 이동
  const handleConfirmClick = () => {
    // 선택된 강좌 목록과 함께 selectedDateFull 정보를 Plan 페이지로 전달
    navigate('/plan', { state: { selectedCourses: selectedCourses, selectedDateFull: selectedDateFull } });
  };

  return (
    <div className="recommendations-container">
      {/* 여기에 날짜 정보를 표시하고 싶다면 selectedDateFull을 사용할 수 있습니다. */}
      <div className="name">{subject} ❯ {category} ❯ {difficulty}</div>
      <div className="course-list">
        {availableCourses.length > 0 ? (
          availableCourses.map((course) => (
            <div className="course-item" key={course.id}>
              <img src={course.logo} alt="로고" className="course-logo" />
              <label className="course-title" htmlFor={`course-${course.id}`}>
                {course.title}
              </label>
              <input
                type="checkbox"
                id={`course-${course.id}`}
                checked={selectedCourses.some(c => c.id === course.id)}
                onChange={() => handleCheckboxChange(course)}
              />
            </div>
          ))
        ) : (
          <p>추천 강좌가 없습니다.</p>
        )}
      </div>
      <button className="confirm-button" onClick={handleConfirmClick}>선택</button>
    </div>
  );
};

export default Recommendations;
