import React, { useState } from 'react';
import './home.css';

const Home = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  const [categories, setCategories] = useState(['세부과목']); 

  const handleDateClick = (day) => {
    setSelectedDate(day);
  };

  const handleSubjectClick = (subject) => {
    if (subject === '수학') {
      setCategories(['확통', '미적', '기하', '수1', '수2']);
    } else if (subject === '영어') {
      setCategories(['듣기', '문법', '독해']);
    } else {
      setCategories(['독서', '문학', '언어와 매체']); 
    }
  };

  return (
    <div className="main-container">
      <div className="container1">
        <h1 className="title">학습 계획표</h1>
        <div className="calendar">
          <div className="calendar-header">
            <button className="nav-button">◀</button>
            <span className="month">2025. 03</span>
            <button className="nav-button">▶</button>
          </div>
          <div className="days">
            {[...Array(31)].map((_, i) => {
              const day = i + 1;
              return (
                <span
                  key={day}
                  className={`day ${day === selectedDate ? 'selected' : ''}`}
                  onClick={() => handleDateClick(day)}
                >
                  {day}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      <div className="container2">
        <div className="subject-selection">
          <button className="subject-button" onClick={() => handleSubjectClick('국어')}>국어</button>
          <button className="subject-button" onClick={() => handleSubjectClick('수학')}>수학</button>
          <button className="subject-button" onClick={() => handleSubjectClick('영어')}>영어</button>
        </div>
        <div className="subject-box">
          <select className="custom-select">
            <option>세부과목</option>
            {categories.map((category, index) => (
              <option key={index}>{category}</option>
            ))}
          </select>
        </div>
        <div className="subject-box">
          <select className="custom-select">
            <option>난이도</option>
            <option>개념</option>
            <option>심화</option>
          </select>
        </div>
      </div>

      <div className="button-container">
        <div className="link">
          <a href="#">내 계획 확인하러 가기 ≫</a>
        </div>
        <button className="select-button">선택</button>
      </div>
    </div>
  );
};

export default Home;
