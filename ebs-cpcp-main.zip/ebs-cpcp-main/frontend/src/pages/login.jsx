// src/pages/login.jsx
import React from 'react';

const Login = () => {
  return (
    <div>
      <h2>로그인 페이지</h2>
      {/* 로그인 관련 요소들 */}
    </div>
  );
};

export default Login; // 기본 내보내기
